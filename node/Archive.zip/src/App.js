import logo from './logo.svg';
import './App.scss';
import NowPlaying from './widgets/nowplaying/nowplaying';



function App() {
  return (
    <div className="App">
      <NowPlaying></NowPlaying>
    </div>
  );
}

export default App;
