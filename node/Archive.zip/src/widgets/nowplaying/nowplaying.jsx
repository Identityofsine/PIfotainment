
import React from 'react'
import "./nowplaying.scss"
import "../widget.scss"
//import TextTicker from 'react-native-text-ticker'

function NowPlaying() {
  return (
    <div className='widget nowplaying'>
        <div className='album'>
            <img src="dev.png"></img>
            <h1>A Rush Of Blood Head</h1>
        </div>
        <div className='trackinfo'>
          <div className='scroll'><h2>A Rush Of Blood Head</h2></div>
          <progress id="track" value={124/170 * 100} max="100"> </progress>
         <span>2:04 / 2:49</span>
          <p>A Rush Of Blood Head</p>
          <h2>Coldplay</h2>
        </div>

    </div>
  )
}

export default NowPlaying